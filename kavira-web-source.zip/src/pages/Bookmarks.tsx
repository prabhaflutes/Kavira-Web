import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { fetchUserBookmarks } from "../firebase/works";
import type { Work } from "../types";
import WorkCard from "../components/WorkCard";

export default function Bookmarks() {
  const { user } = useAuth();
  const [works, setWorks] = useState<Work[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchUserBookmarks(user.uid).then((w) => {
      setWorks(w);
      setLoading(false);
    });
  }, [user]);

  return (
    <div className="page">
      <h1 className="page-title">बुकमार्क</h1>
      <p className="page-subtitle">बाद में पढ़ने के लिए सुरक्षित की गई रचनाएँ।</p>

      {loading && <div className="spinner" />}

      {!loading && works.length === 0 && (
        <div className="empty-state">आपकी बुकमार्क की गई रचनाएँ यहाँ दिखेंगी।</div>
      )}

      {!loading && works.length > 0 && (
        <div className="works">
          {works.map((w) => (
            <WorkCard key={w.id} work={w} />
          ))}
        </div>
      )}
    </div>
  );
}
