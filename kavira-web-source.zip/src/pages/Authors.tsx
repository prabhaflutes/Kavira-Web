import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchWriters, toggleFollow, isFollowing } from "../firebase/users";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../components/Toast";
import type { UserProfile } from "../types";

export default function Authors() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [writers, setWriters] = useState<UserProfile[]>([]);
  const [followState, setFollowState] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWriters().then(async (list) => {
      setWriters(list);
      setLoading(false);
      if (user) {
        const entries = await Promise.all(
          list.map(async (w) => [w.uid, await isFollowing(user.uid, w.uid)] as const)
        );
        setFollowState(Object.fromEntries(entries));
      }
    });
  }, [user]);

  async function handleFollow(e: React.MouseEvent, uid: string) {
    e.stopPropagation();
    if (!user) {
      navigate("/login");
      return;
    }
    const currently = !!followState[uid];
    setFollowState((prev) => ({ ...prev, [uid]: !currently }));
    await toggleFollow(user.uid, uid, currently);
    showToast(!currently ? "अब आप इस लेखक को फॉलो कर रहे हैं।" : "फॉलो करना बंद कर दिया गया।");
  }

  return (
    <div className="page">
      <h1 className="page-title">लेखक</h1>
      <p className="page-subtitle">हिंदी साहित्य की नई और स्थापित आवाज़ों को खोजें।</p>

      {loading && <div className="spinner" />}

      {!loading && writers.length === 0 && (
        <div className="empty-state">अभी कोई लेखक पंजीकृत नहीं है।</div>
      )}

      {!loading && writers.length > 0 && (
        <div className="cards">
          {writers.map((w) => (
            <article key={w.uid} className="author-card" onClick={() => navigate(`/author/${w.uid}`)}>
              <img src={w.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${w.displayName}`} />
              <h3>{w.displayName}</h3>
              <p>@{w.username}</p>
              <p>{w.worksCount} रचनाएँ · {w.followersCount} फॉलोअर्स</p>
              <button className="follow" onClick={(e) => handleFollow(e, w.uid)}>
                {followState[w.uid] ? "फॉलोइंग" : "फॉलो"}
              </button>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
