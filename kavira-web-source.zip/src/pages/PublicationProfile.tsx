import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getPublication } from "../firebase/publications";
import type { Publication } from "../types";

export default function PublicationProfile() {
  const { id } = useParams<{ id: string }>();
  const [pub, setPub] = useState<Publication | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    getPublication(id).then((p) => {
      setPub(p);
      setLoading(false);
    });
  }, [id]);

  if (loading) return <div className="spinner" />;
  if (!pub) return <div className="empty-state">यह प्रकाशन नहीं मिला।</div>;

  return (
    <div className="page">
      <div className="profile-header">
        <div
          style={{
            width: 105,
            height: 105,
            borderRadius: 20,
            background: "var(--forest)",
            color: "white",
            display: "grid",
            placeItems: "center",
            fontSize: 42
          }}
        >
          📚
        </div>
        <div>
          <h1 className="page-title">
            {pub.name} {pub.verified && "✓"}
          </h1>
          <p>{pub.type}</p>
          <p className="profile-description">{pub.description}</p>
          <button className="btn" style={{ marginTop: 10 }}>
            संपर्क करें
          </button>
        </div>
      </div>
    </div>
  );
}
