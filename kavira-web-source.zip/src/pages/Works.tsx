import { useEffect, useState } from "react";
import { fetchPublishedWorks, fetchWorksByCategory } from "../firebase/works";
import type { Work } from "../types";
import WorkCard from "../components/WorkCard";

const CATEGORIES = ["सभी", "कविता", "कहानी", "लेख", "निबंध", "उपन्यास"];

export default function Works() {
  const [works, setWorks] = useState<Work[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState("सभी");

  useEffect(() => {
    setLoading(true);
    const loader =
      active === "सभी" ? fetchPublishedWorks().then((r) => r.works) : fetchWorksByCategory(active);
    loader.then((w) => {
      setWorks(w);
      setLoading(false);
    });
  }, [active]);

  return (
    <div className="page">
      <h1 className="page-title">सभी रचनाएँ</h1>
      <p className="page-subtitle">कविता, कहानी, लेख, निबंध और साहित्य।</p>

      <div className="category-list" style={{ marginBottom: 20 }}>
        {CATEGORIES.map((c) => (
          <div
            key={c}
            className={`category ${active === c ? "active" : ""}`}
            onClick={() => setActive(c)}
          >
            {c}
          </div>
        ))}
      </div>

      {loading && <div className="spinner" />}

      {!loading && works.length === 0 && (
        <div className="empty-state">इस श्रेणी में अभी कोई रचना नहीं है।</div>
      )}

      {!loading && works.length > 0 && (
        <div className="works">
          {works.map((w) => (
            <WorkCard key={w.id} work={w} />
          ))}
        </div>
      )}
    </div>
  );
}
