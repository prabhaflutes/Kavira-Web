import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getWork, toggleLike, checkUserLiked, toggleBookmark } from "../firebase/works";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../components/Toast";
import type { Work } from "../types";

export default function Reading() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [work, setWork] = useState<Work | null>(null);
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    getWork(id).then((w) => {
      setWork(w);
      setLoading(false);
    });
    if (id && user) {
      checkUserLiked(id, user.uid).then(setLiked);
    }
  }, [id, user]);

  async function handleLike() {
    if (!user || !work) return;
    const next = !liked;
    setLiked(next);
    setWork({ ...work, likesCount: work.likesCount + (next ? 1 : -1) });
    await toggleLike(work.id, user.uid, liked);
    showToast(next ? "रचना पसंद की गई।" : "पसंद हटा दी गई।");
  }

  async function handleBookmark() {
    if (!user || !work) return;
    const next = !bookmarked;
    setBookmarked(next);
    await toggleBookmark(work.id, user.uid, bookmarked);
    showToast(next ? "रचना बुकमार्क हो गई।" : "बुकमार्क हटा दिया गया।");
  }

  async function handleShare() {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: "Kavira", text: "यह रचना Kavira पर पढ़ें।", url });
      } catch {}
    } else {
      await navigator.clipboard.writeText(url);
      showToast("लिंक कॉपी हो गया।");
    }
  }

  if (loading) return <div className="spinner" />;
  if (!work) return <div className="empty-state">यह रचना उपलब्ध नहीं है।</div>;

  const isPoem = work.type === "कविता" || work.type === "ग़ज़ल" || work.type === "शायरी";

  return (
    <div className="page reading">
      <div className="reading-card">
        <div className="reading-category">
          {work.category} · {work.type}
        </div>
        <h1 className="reading-title">{work.title}</h1>
        <div className="reading-author">{work.authorName}</div>

        <div className={isPoem ? "poem" : "story"}>{work.content}</div>

        <div
          style={{
            marginTop: 30,
            paddingTop: 18,
            borderTop: "1px solid var(--border)",
            display: "flex",
            gap: 10,
            flexWrap: "wrap"
          }}
        >
          <button className="btn" onClick={handleLike}>
            {liked ? "♥" : "♡"} {work.likesCount}
          </button>
          <button className="btn secondary">□ {work.commentsCount}</button>
          <button className="btn secondary" onClick={handleBookmark}>
            🔖 {bookmarked ? "सेव किया" : "बुकमार्क"}
          </button>
          <button className="btn secondary" onClick={handleShare}>
            ↗ साझा करें
          </button>
        </div>
      </div>
    </div>
  );
}
