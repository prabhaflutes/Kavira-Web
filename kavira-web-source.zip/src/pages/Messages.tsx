import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { listenToConversations, listenToMessages, sendMessage } from "../firebase/messages";
import type { Conversation, Message } from "../types";

export default function Messages() {
  const { user, profile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");

  useEffect(() => {
    if (!user) return;
    const unsub = listenToConversations(user.uid, (list) => {
      setConversations(list);
      if (!activeId && list.length > 0) setActiveId(list[0].id);
    });
    return unsub;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  useEffect(() => {
    if (!activeId) return;
    const unsub = listenToMessages(activeId, setMessages);
    return unsub;
  }, [activeId]);

  async function handleSend() {
    if (!input.trim() || !activeId || !user) return;
    await sendMessage(activeId, user.uid, input.trim());
    setInput("");
  }

  const active = conversations.find((c) => c.id === activeId);
  const otherName = active && user
    ? active.participantNames[active.participantIds.find((p) => p !== user.uid) || ""]
    : "";

  return (
    <div className="page">
      <h1 className="page-title">संदेश</h1>
      <p className="page-subtitle">लेखकों और प्रकाशनों से बातचीत करें।</p>

      <div className="message-layout">
        <div className="message-list">
          {conversations.length === 0 && (
            <div className="empty-state">अभी कोई बातचीत नहीं है।</div>
          )}
          {conversations.map((c) => {
            const otherUid = c.participantIds.find((p) => p !== user?.uid) || "";
            return (
              <div
                key={c.id}
                className={`message-user ${c.id === activeId ? "active" : ""}`}
                onClick={() => setActiveId(c.id)}
              >
                <img src={c.participantPhotos[otherUid] || "https://api.dicebear.com/7.x/initials/svg?seed=K"} />
                <div>
                  <strong style={{ fontSize: 12 }}>{c.participantNames[otherUid]}</strong>
                  <div style={{ fontSize: 10, color: "var(--muted)" }}>{c.lastMessage}</div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="chat">
          {active ? (
            <>
              <div className="chat-header">{otherName}</div>
              <div className="chat-body">
                {messages.map((m) => (
                  <div
                    key={m.id}
                    className={`bubble ${m.senderId === user?.uid ? "sent" : "received"}`}
                  >
                    {m.text}
                  </div>
                ))}
              </div>
              <div className="chat-input">
                <input
                  placeholder="संदेश लिखें..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                />
                <button className="btn" onClick={handleSend}>
                  भेजें
                </button>
              </div>
            </>
          ) : (
            <div className="empty-state">कोई बातचीत चुनें।</div>
          )}
        </div>
      </div>
    </div>
  );
}
