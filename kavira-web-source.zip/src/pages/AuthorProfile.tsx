import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getUserProfile, toggleFollow, isFollowing } from "../firebase/users";
import { fetchWorksByAuthor } from "../firebase/works";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../components/Toast";
import type { UserProfile, Work } from "../types";
import WorkCard from "../components/WorkCard";

export default function AuthorProfile() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [author, setAuthor] = useState<UserProfile | null>(null);
  const [works, setWorks] = useState<Work[]>([]);
  const [following, setFollowing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    Promise.all([getUserProfile(id), fetchWorksByAuthor(id)]).then(([a, w]) => {
      setAuthor(a);
      setWorks(w);
      setLoading(false);
    });
    if (id && user) {
      isFollowing(user.uid, id).then(setFollowing);
    }
  }, [id, user]);

  async function handleFollow() {
    if (!user || !id) {
      navigate("/login");
      return;
    }
    const next = !following;
    setFollowing(next);
    await toggleFollow(user.uid, id, following);
    showToast(next ? "अब आप इस लेखक को फॉलो कर रहे हैं।" : "फॉलो करना बंद कर दिया गया।");
  }

  if (loading) return <div className="spinner" />;
  if (!author) return <div className="empty-state">यह लेखक नहीं मिला।</div>;

  return (
    <div className="page">
      <div className="profile-header">
        <img
          className="profile-large"
          src={author.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${author.displayName}`}
        />
        <div>
          <h1 className="page-title">{author.displayName}</h1>
          <p>@{author.username}</p>
          <p className="profile-description">{author.bio || "इस लेखक ने अभी तक कोई परिचय नहीं जोड़ा है।"}</p>
          <div style={{ marginTop: 12 }}>
            <button className="btn" onClick={handleFollow}>
              {following ? "फॉलोइंग" : "फॉलो करें"}
            </button>
            <button className="btn secondary" onClick={() => navigate("/messages")} style={{ marginLeft: 8 }}>
              संदेश भेजें
            </button>
          </div>
        </div>
      </div>

      <section className="section">
        <div className="section-head">
          <h2>रचनाएँ</h2>
        </div>
        {works.length === 0 ? (
          <div className="empty-state">अभी कोई रचना उपलब्ध नहीं है।</div>
        ) : (
          <div className="works">
            {works.map((w) => (
              <WorkCard key={w.id} work={w} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
