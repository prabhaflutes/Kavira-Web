import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchPublications } from "../firebase/publications";
import type { Publication } from "../types";

export default function Publications() {
  const navigate = useNavigate();
  const [pubs, setPubs] = useState<Publication[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPublications().then((p) => {
      setPubs(p);
      setLoading(false);
    });
  }, []);

  return (
    <div className="page">
      <h1 className="page-title">प्रकाशन</h1>
      <p className="page-subtitle">साहित्यिक पत्रिकाओं, प्रकाशकों और संपादकीय संस्थाओं से जुड़ें।</p>

      {loading && <div className="spinner" />}

      {!loading && pubs.length === 0 && (
        <div className="empty-state">अभी कोई प्रकाशन पंजीकृत नहीं है।</div>
      )}

      {!loading && pubs.length > 0 && (
        <div className="cards">
          {pubs.map((p) => (
            <article key={p.id} className="generic-card" onClick={() => navigate(`/publication/${p.id}`)} style={{ cursor: "pointer" }}>
              <div style={{ fontSize: 30, marginBottom: 10 }}>📚</div>
              <h3>{p.name} {p.verified && "✓"}</h3>
              <p>{p.type}</p>
              <p>{p.followersCount} followers</p>
              <p style={{ marginTop: 10 }}>{p.description}</p>
              <button className="btn" style={{ marginTop: 12, fontSize: 11 }}>
                प्रोफ़ाइल देखें
              </button>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
