import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { fetchDraftsByAuthor, deleteWork } from "../firebase/works";
import { useToast } from "../components/Toast";
import type { Work } from "../types";

function timeAgo(ts: number): string {
  if (!ts) return "";
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins} मिनट पहले`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} घंटे पहले`;
  return `${Math.floor(hours / 24)} दिन पहले`;
}

export default function Drafts() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [drafts, setDrafts] = useState<Work[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchDraftsByAuthor(user.uid).then((d) => {
      setDrafts(d);
      setLoading(false);
    });
  }, [user]);

  async function handleDelete(id: string) {
    await deleteWork(id);
    setDrafts((prev) => prev.filter((d) => d.id !== id));
    showToast("ड्राफ्ट हटा दिया गया।");
  }

  return (
    <div className="page">
      <h1 className="page-title">ड्राफ्ट्स</h1>
      <p className="page-subtitle">आपकी अधूरी रचनाएँ।</p>

      {loading && <div className="spinner" />}

      {!loading && drafts.length === 0 && (
        <div className="empty-state">आपके ड्राफ्ट यहाँ दिखेंगे।</div>
      )}

      {!loading && drafts.length > 0 && (
        <div className="cards">
          {drafts.map((d) => (
            <div key={d.id} className="generic-card">
              <span className="open">ड्राफ्ट</span>
              <h3 style={{ marginTop: 9 }}>{d.title}</h3>
              <p>
                {d.type} · आखिरी संपादन {timeAgo(d.updatedAt)}
              </p>
              <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                <button className="btn" style={{ fontSize: 11 }} onClick={() => navigate(`/publish?draft=${d.id}`)}>
                  संपादित करें
                </button>
                <button className="btn secondary" style={{ fontSize: 11 }} onClick={() => handleDelete(d.id)}>
                  हटाएं
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
