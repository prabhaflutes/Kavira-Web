import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export default function AuthComplete() {
  const { completeEmailLinkSignIn } = useAuth();
  const [status, setStatus] = useState<"working" | "done" | "error">("working");

  useEffect(() => {
    completeEmailLinkSignIn()
      .then((ok) => setStatus(ok ? "done" : "error"))
      .catch(() => setStatus("error"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (status === "done") {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: "center" }}>
        <div className="auth-brand">Kavira</div>
        {status === "working" && (
          <>
            <div className="spinner" />
            <p style={{ color: "var(--muted)", fontSize: 13 }}>लॉगिन पूरा किया जा रहा है...</p>
          </>
        )}
        {status === "error" && (
          <div className="auth-error">
            लिंक अमान्य है या समय समाप्त हो गया है। कृपया पुनः लॉगिन करें।
          </div>
        )}
      </div>
    </div>
  );
}
