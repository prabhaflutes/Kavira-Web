import { useNavigate } from "react-router-dom";

const categories: [string, string, string][] = [
  ["🌿", "कविता", "हिंदी कविता और मुक्त छंद"],
  ["📖", "कहानी", "लघुकथा और कहानी"],
  ["📝", "लेख", "विचार और समसामयिक लेख"],
  ["🪶", "निबंध", "साहित्यिक एवं वैचारिक निबंध"],
  ["📕", "उपन्यास", "उपन्यास एवं धारावाहिक रचनाएँ"],
  ["🪷", "बाल साहित्य", "बच्चों के लिए साहित्य"],
  ["🌱", "प्रकृति", "प्रकृति और पर्यावरण"],
  ["❤️", "प्रेम", "प्रेम और रिश्ते"],
  ["🕯️", "दर्शन", "जीवन और दर्शन"],
  ["🏛️", "इतिहास", "इतिहास और संस्कृति"],
  ["🌙", "आध्यात्म", "आध्यात्मिक लेखन"],
  ["✒️", "अन्य", "अन्य साहित्यिक रचनाएँ"]
];

export default function Categories() {
  const navigate = useNavigate();

  return (
    <div className="page">
      <h1 className="page-title">साहित्य की दुनिया</h1>
      <p className="page-subtitle">अपनी पसंद की विधा चुनें।</p>

      <div className="cards">
        {categories.map(([icon, name, desc]) => (
          <div key={name} className="generic-card" style={{ cursor: "pointer" }} onClick={() => navigate("/works")}>
            <div style={{ fontSize: 28, marginBottom: 7 }}>{icon}</div>
            <h3>{name}</h3>
            <p>{desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
