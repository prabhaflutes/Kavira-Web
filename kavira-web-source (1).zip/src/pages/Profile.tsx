import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { fetchWorksByAuthor } from "../firebase/works";
import { updateUserProfile } from "../firebase/users";
import { useToast } from "../components/Toast";
import type { Work } from "../types";
import WorkCard from "../components/WorkCard";

export default function Profile() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();
  const { showToast } = useToast();
  const [works, setWorks] = useState<Work[]>([]);
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");

  useEffect(() => {
    if (!user) return;
    fetchWorksByAuthor(user.uid).then(setWorks);
  }, [user]);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName);
      setBio(profile.bio);
    }
  }, [profile]);

  async function handleSave() {
    if (!user) return;
    await updateUserProfile(user.uid, { displayName, bio });
    await refreshProfile();
    setEditing(false);
    showToast("प्रोफ़ाइल अपडेट हो गई।");
  }

  if (!profile) return <div className="spinner" />;

  return (
    <div className="page">
      <div className="profile-header">
        <img
          className="profile-large"
          src={profile.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${profile.displayName}`}
        />
        <div style={{ flex: 1 }}>
          {editing ? (
            <>
              <div className="field">
                <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              </div>
              <div className="field">
                <textarea
                  style={{ minHeight: 80 }}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="अपना परिचय लिखें..."
                />
              </div>
              <button className="btn" onClick={handleSave}>
                सुरक्षित करें
              </button>
            </>
          ) : (
            <>
              <h1 className="page-title">{profile.displayName}</h1>
              <p>@{profile.username}</p>
              <p className="profile-description">{profile.bio || "अभी तक कोई परिचय नहीं जोड़ा गया।"}</p>
              <button className="btn" style={{ marginTop: 12 }} onClick={() => setEditing(true)}>
                प्रोफ़ाइल संपादित करें
              </button>
            </>
          )}
        </div>
      </div>

      <section className="section">
        <div className="section-head">
          <h2>मेरी रचनाएँ</h2>
          <a onClick={() => navigate("/publish")}>+ नई रचना</a>
        </div>
        {works.length === 0 ? (
          <div className="empty-state">आपने अभी तक कोई रचना प्रकाशित नहीं की है।</div>
        ) : (
          <div className="works">
            {works.map((w) => (
              <WorkCard key={w.id} work={w} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
