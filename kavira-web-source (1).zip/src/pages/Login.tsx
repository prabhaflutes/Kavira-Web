import { useState } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export default function Login() {
  const { user, loading, signInWithGoogle, sendEmailLink } = useAuth();
  const [email, setEmail] = useState("");
  const [linkSent, setLinkSent] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (!loading && user) {
    return <Navigate to="/" replace />;
  }

  async function handleGoogle() {
    setError("");
    setBusy(true);
    try {
      await signInWithGoogle();
    } catch (e: any) {
      setError("Google से लॉगिन नहीं हो सका। पुनः प्रयास करें।");
    } finally {
      setBusy(false);
    }
  }

  async function handleEmailLink() {
    if (!email.trim()) {
      setError("कृपया अपना ईमेल दर्ज करें।");
      return;
    }
    setError("");
    setBusy(true);
    try {
      await sendEmailLink(email.trim());
      setLinkSent(true);
    } catch (e: any) {
      setError("लिंक भेजने में समस्या हुई। पुनः प्रयास करें।");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand">Kavira</div>
        <div className="auth-tagline">शब्दों से जुड़े दिल</div>

        {error && <div className="auth-error">{error}</div>}
        {linkSent && (
          <div className="auth-success">
            {email} पर लॉगिन लिंक भेज दिया गया है। अपना ईमेल खोलें और लिंक पर टैप करें।
          </div>
        )}

        {!linkSent && (
          <>
            <div className="field">
              <label>ईमेल</label>
              <input
                type="email"
                placeholder="आपका ईमेल पता"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <button className="btn" style={{ width: "100%" }} onClick={handleEmailLink} disabled={busy}>
              लॉगिन लिंक भेजें
            </button>

            <div className="auth-divider">या</div>

            <button className="google-btn" onClick={handleGoogle} disabled={busy}>
              Google से जारी रखें
            </button>
          </>
        )}
      </div>
    </div>
  );
}
