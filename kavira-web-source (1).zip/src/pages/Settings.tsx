import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../components/Toast";

interface SettingsProps {
  dark: boolean;
  setDark: (v: boolean) => void;
}

export default function Settings({ dark, setDark }: SettingsProps) {
  const { signOut } = useAuth();
  const { showToast } = useToast();
  const [notificationsOn, setNotificationsOn] = useState(true);

  async function handleLogout() {
    await signOut();
    showToast("आपको सुरक्षित रूप से लॉग आउट किया गया।");
  }

  return (
    <div className="page settings">
      <h1 className="page-title">सेटिंग्स</h1>
      <p className="page-subtitle">अपने Kavira अनुभव को अपनी पसंद के अनुसार बदलें।</p>

      <div className="setting">
        <div className="setting-info">
          <h3>🌙 डार्क मोड</h3>
          <p>कम रोशनी में आरामदायक पढ़ने का अनुभव।</p>
        </div>
        <div className={`toggle ${dark ? "active" : ""}`} onClick={() => setDark(!dark)}>
          <span></span>
        </div>
      </div>

      <div className="setting">
        <div className="setting-info">
          <h3>🔔 सूचनाएँ</h3>
          <p>नई गतिविधियों की जानकारी प्राप्त करें।</p>
        </div>
        <div
          className={`toggle ${notificationsOn ? "active" : ""}`}
          onClick={() => setNotificationsOn(!notificationsOn)}
        >
          <span></span>
        </div>
      </div>

      <div className="setting">
        <div className="setting-info">
          <h3>🌐 भाषा</h3>
          <p>इंटरफेस की भाषा।</p>
        </div>
        <select
          style={{
            border: "1px solid var(--border)",
            padding: 7,
            borderRadius: 6,
            background: "var(--cream)",
            color: "var(--text)"
          }}
        >
          <option>हिन्दी</option>
          <option>English</option>
        </select>
      </div>

      <div className="setting">
        <div className="setting-info">
          <h3>🔐 गोपनीयता</h3>
          <p>प्रोफ़ाइल और संदेशों की privacy settings।</p>
        </div>
        <button className="follow">प्रबंधित करें</button>
      </div>

      <div className="setting">
        <div className="setting-info">
          <h3>🚪 लॉग आउट</h3>
          <p>इस डिवाइस से अपना account sign out करें।</p>
        </div>
        <button className="follow" style={{ color: "#c44", borderColor: "#c44" }} onClick={handleLogout}>
          लॉग आउट
        </button>
      </div>
    </div>
  );
}
