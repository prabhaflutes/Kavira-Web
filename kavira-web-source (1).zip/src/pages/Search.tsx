import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { fetchPublishedWorks } from "../firebase/works";
import type { Work } from "../types";
import WorkCard from "../components/WorkCard";

export default function Search() {
  const [params, setParams] = useSearchParams();
  const query = params.get("q") || "";
  const [input, setInput] = useState(query);
  const [allWorks, setAllWorks] = useState<Work[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPublishedWorks()
      .then(({ works }) => setAllWorks(works))
      .finally(() => setLoading(false));
  }, []);

  const results = query
    ? allWorks.filter(
        (w) =>
          w.title.toLowerCase().includes(query.toLowerCase()) ||
          w.authorName.toLowerCase().includes(query.toLowerCase()) ||
          w.type.toLowerCase().includes(query.toLowerCase()) ||
          w.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()))
      )
    : allWorks;

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      setParams(input ? { q: input } : {});
    }
  }

  return (
    <div className="page search-page">
      <h1 className="page-title">खोजें</h1>
      <p className="page-subtitle">कविताएँ, कहानियाँ, लेखक और प्रकाशन खोजें।</p>

      <input
        className="search-large"
        placeholder="कुछ खोजें..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
      />

      <div className="section-head">
        <h2>{query ? `"${query}" के परिणाम` : "लोकप्रिय रचनाएँ"}</h2>
      </div>

      {loading && <div className="spinner" />}

      {!loading && results.length === 0 && (
        <div className="empty-state">कोई परिणाम नहीं मिला।</div>
      )}

      {!loading && results.length > 0 && (
        <div className="works">
          {results.map((w) => (
            <WorkCard key={w.id} work={w} />
          ))}
        </div>
      )}
    </div>
  );
}
