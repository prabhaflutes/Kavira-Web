import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchOpenCalls } from "../firebase/publications";
import type { OpenCall } from "../types";

function formatDate(ts: number): string {
  if (!ts) return "";
  const d = new Date(ts);
  return d.toLocaleDateString("hi-IN", { day: "numeric", month: "long", year: "numeric" });
}

export default function Calls() {
  const navigate = useNavigate();
  const [calls, setCalls] = useState<OpenCall[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOpenCalls()
      .then((c) => setCalls(c))
      .catch((e) => console.error(e))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <h1 className="page-title">ओपन कॉल्स</h1>
      <p className="page-subtitle">प्रकाशनों द्वारा आमंत्रित वर्तमान लेखन अवसर।</p>

      {loading && <div className="spinner" />}

      {!loading && calls.length === 0 && (
        <div className="empty-state">अभी कोई ओपन कॉल उपलब्ध नहीं है।</div>
      )}

      {!loading && calls.length > 0 && (
        <div className="cards">
          {calls.map((c) => (
            <div key={c.id} className="generic-card">
              <span className="open">{c.genre}</span>
              <h3 style={{ marginTop: 10 }}>{c.title}</h3>
              <p>{c.publicationName}</p>
              <p>
                अंतिम तिथि: <strong>{formatDate(c.deadline)}</strong>
              </p>
              <button className="btn" style={{ marginTop: 12, fontSize: 11 }} onClick={() => navigate("/publish")}>
                रचना भेजें
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
