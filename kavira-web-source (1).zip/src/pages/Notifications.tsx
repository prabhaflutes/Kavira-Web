import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { listenToNotifications } from "../firebase/notifications";
import type { AppNotification } from "../types";

export default function Notifications() {
  const { user } = useAuth();
  const [items, setItems] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const unsub = listenToNotifications(
      user.uid,
      (list) => {
        setItems(list);
        setLoading(false);
      },
      () => setLoading(false)
    );
    return unsub;
  }, [user]);

  return (
    <div className="page">
      <h1 className="page-title">सूचनाएँ</h1>
      <p className="page-subtitle">आपकी नवीनतम गतिविधियाँ।</p>

      {loading && <div className="spinner" />}

      {!loading && items.length === 0 && (
        <div className="empty-state">अभी कोई सूचना नहीं है।</div>
      )}

      {!loading && items.length > 0 && (
        <div className="generic-card">
          {items.map((n) => (
            <div
              key={n.id}
              style={{
                padding: "15px 0",
                borderBottom: "1px solid var(--border)",
                fontSize: 13,
                opacity: n.read ? 0.6 : 1
              }}
            >
              ♧ &nbsp; {n.text}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
