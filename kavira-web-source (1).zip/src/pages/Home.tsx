import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchPublishedWorks } from "../firebase/works";
import { useAuth } from "../contexts/AuthContext";
import type { Work } from "../types";
import WorkCard from "../components/WorkCard";

const CATEGORIES = ["🌿 कविता", "📖 कहानी", "📝 लेख", "🪶 निबंध", "📕 उपन्यास", "🪷 बाल साहित्य", "🌱 दर्शन"];

export default function Home() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [works, setWorks] = useState<Work[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPublishedWorks()
      .then(({ works }) => setWorks(works))
      .finally(() => setLoading(false));
  }, []);

  const featured = works[0];

  return (
    <div className="page">
      <div className="dashboard">
        <section className="content">
          <section className="hero">
            <div className="hero-content">
              <h1>हर शब्द में एक संसार बसता है।</h1>
              <p>
                कविताएँ, कहानियाँ, लेख और विचार — यहाँ शब्दों को मिलते हैं पाठक, और लेखकों को मिलता
                है अपना मंच।
              </p>
              <div className="buttons">
                <button className="btn" onClick={() => navigate("/works")}>
                  रचना पढ़ें
                </button>
                <button className="btn secondary" onClick={() => navigate("/publish")}>
                  रचना लिखें
                </button>
              </div>
            </div>
          </section>

          {featured && (
            <section className="section">
              <div
                className="featured"
                onClick={() => navigate(`/read/${featured.id}`)}
                style={{ cursor: "pointer" }}
              >
                <div className="featured-label">✧ विशेष चयन</div>
                <h2>{featured.title}</h2>
                <div className="featured-author">
                  {featured.authorName} · {featured.type}
                </div>
                <p className="featured-text">{featured.content.slice(0, 120)}</p>
                <div className="stats">
                  <span>♡ {featured.likesCount}</span>
                  <span>□ {featured.commentsCount}</span>
                  <span>♡ {featured.bookmarksCount}</span>
                </div>
              </div>
            </section>
          )}

          <section className="section">
            <div className="section-head">
              <h2>ट्रेंडिंग रचनाएँ</h2>
              <a onClick={() => navigate("/works")}>सभी देखें</a>
            </div>

            {loading && <div className="spinner" />}

            {!loading && works.length === 0 && (
              <div className="empty-state">
                अभी कोई रचना प्रकाशित नहीं हुई है। सबसे पहले लिखने वाले आप हो सकते हैं।
              </div>
            )}

            {!loading && works.length > 0 && (
              <div className="works">
                {works.slice(0, 4).map((w) => (
                  <WorkCard key={w.id} work={w} />
                ))}
              </div>
            )}
          </section>

          <section className="section">
            <div className="section-head">
              <h2>लोकप्रिय श्रेणियाँ</h2>
              <a onClick={() => navigate("/categories")}>और देखें</a>
            </div>
            <div className="category-list">
              {CATEGORIES.map((c) => (
                <div key={c} className="category" onClick={() => navigate("/works")}>
                  {c}
                </div>
              ))}
            </div>
          </section>
        </section>

        <aside className="right">
          <section className="panel profile-panel">
            <div className="profile-top">
              <img
                className="profile-image"
                src={profile?.photoURL || "https://api.dicebear.com/7.x/initials/svg?seed=K"}
              />
              <div>
                <div className="profile-name">{profile?.displayName || "नया लेखक"}</div>
                <div className="profile-handle">@{profile?.username || "user"}</div>
                <div className="profile-handle">लेखक</div>
              </div>
            </div>
            <div className="profile-stats">
              <div>
                <strong>{profile?.worksCount ?? 0}</strong>
                <span>रचनाएँ</span>
              </div>
              <div>
                <strong>{profile?.followersCount ?? 0}</strong>
                <span>फॉलोअर्स</span>
              </div>
              <div>
                <strong>{profile?.followingCount ?? 0}</strong>
                <span>फॉलोइंग</span>
              </div>
            </div>
            <button className="profile-btn" onClick={() => navigate("/profile")}>
              प्रोफ़ाइल देखें
            </button>
          </section>

          <section className="quote">
            "शब्द ही वह पुल हैं, जो मन से मन तक पहुँचते हैं।"
            <div className="quote-author">— गुलज़ार</div>
          </section>
        </aside>
      </div>
    </div>
  );
}
