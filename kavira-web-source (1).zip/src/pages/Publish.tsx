import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { createWork } from "../firebase/works";
import { useToast } from "../components/Toast";
import type { WorkType } from "../types";

const TYPES: WorkType[] = ["कविता", "कहानी", "लघुकथा", "उपन्यास", "ग़ज़ल", "शायरी", "लेख", "निबंध", "अन्य"];
const LANGUAGES = ["हिन्दी", "English", "বাংলা", "मराठी", "Other"];

export default function Publish() {
  const { user, profile } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [type, setType] = useState<WorkType>("कविता");
  const [language, setLanguage] = useState("हिन्दी");
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);

  async function handleSave(status: "draft" | "published") {
    if (!user || !profile) return;
    if (!title.trim() || !content.trim()) {
      showToast("कृपया शीर्षक और रचना लिखें।");
      return;
    }
    setSaving(true);
    try {
      const id = await createWork({
        authorId: user.uid,
        authorName: profile.displayName,
        authorPhoto: profile.photoURL,
        title: title.trim(),
        content: content.trim(),
        type,
        category: type,
        language,
        tags: [],
        status
      });
      showToast(status === "published" ? "रचना प्रकाशित हो गई।" : "ड्राफ्ट सुरक्षित कर दिया गया।");
      navigate(status === "published" ? `/read/${id}` : "/drafts");
    } catch (e) {
      showToast("कुछ गलत हो गया। पुनः प्रयास करें।");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="page editor">
      <h1 className="page-title">नई रचना</h1>
      <p className="page-subtitle">अपनी कविता, कहानी या लेख दुनिया के साथ साझा करें।</p>

      <div className="editor-card">
        <div className="field">
          <label>रचना का शीर्षक</label>
          <input
            placeholder="अपनी रचना का शीर्षक लिखें..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div className="field">
          <label>विधा</label>
          <select value={type} onChange={(e) => setType(e.target.value as WorkType)}>
            {TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label>भाषा</label>
          <select value={language} onChange={(e) => setLanguage(e.target.value)}>
            {LANGUAGES.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label>अपनी रचना</label>
          <textarea
            placeholder="यहाँ अपनी रचना लिखें..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
        </div>

        <div className="buttons">
          <button className="btn secondary" onClick={() => handleSave("draft")} disabled={saving}>
            ड्राफ्ट सेव करें
          </button>
          <button className="btn" onClick={() => handleSave("published")} disabled={saving}>
            प्रकाशित करें
          </button>
        </div>
      </div>
    </div>
  );
}
