export default function Help() {
  return (
    <div className="page">
      <h1 className="page-title">हेल्प और सपोर्ट</h1>
      <p className="page-subtitle">Kavira का उपयोग करने में सहायता।</p>

      <div className="cards">
        <div className="generic-card">
          <h3>❓ सामान्य प्रश्न</h3>
          <p>Account, publishing और reading से जुड़े सवाल।</p>
        </div>
        <div className="generic-card">
          <h3>🛡️ सुरक्षा और रिपोर्ट</h3>
          <p>किसी content या account की शिकायत करें।</p>
        </div>
        <div className="generic-card">
          <h3>✉️ संपर्क करें</h3>
          <p>हमारी support team से संपर्क करें।</p>
        </div>
      </div>
    </div>
  );
}
