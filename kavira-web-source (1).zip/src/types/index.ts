export type UserRole = "reader" | "writer" | "publication";

export interface UserProfile {
  uid: string;
  username: string;
  displayName: string;
  bio: string;
  photoURL: string;
  roles: UserRole[];
  location?: string;
  languages: string[];
  website?: string;
  followersCount: number;
  followingCount: number;
  worksCount: number;
  verified: boolean;
  createdAt: number;
}

export type WorkType =
  | "कविता"
  | "कहानी"
  | "लघुकथा"
  | "उपन्यास"
  | "ग़ज़ल"
  | "शायरी"
  | "लेख"
  | "निबंध"
  | "अन्य";

export type WorkStatus = "draft" | "published";

export interface Work {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  title: string;
  subtitle?: string;
  content: string;
  coverImage?: string;
  type: WorkType;
  category: string;
  language: string;
  tags: string[];
  status: WorkStatus;
  likesCount: number;
  commentsCount: number;
  bookmarksCount: number;
  createdAt: number;
  updatedAt: number;
}

export interface Publication {
  id: string;
  ownerId: string;
  name: string;
  logoURL?: string;
  coverURL?: string;
  description: string;
  type: string;
  website?: string;
  followersCount: number;
  verified: boolean;
  createdAt: number;
}

export interface OpenCall {
  id: string;
  publicationId: string;
  publicationName: string;
  title: string;
  genre: string;
  deadline: number;
  requirements: string;
  status: "open" | "closed";
  createdAt: number;
}

export interface Comment {
  id: string;
  workId: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  text: string;
  createdAt: number;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participantNames: Record<string, string>;
  participantPhotos: Record<string, string>;
  lastMessage: string;
  lastMessageAt: number;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  createdAt: number;
  read: boolean;
}

export interface AppNotification {
  id: string;
  userId: string;
  type: "like" | "comment" | "follow" | "message" | "submission" | "system";
  text: string;
  read: boolean;
  createdAt: number;
  link?: string;
}
