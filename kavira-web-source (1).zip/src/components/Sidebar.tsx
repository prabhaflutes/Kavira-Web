import { NavLink } from "react-router-dom";

const items: [string, string, string][] = [
  ["/", "⌂", "होम"],
  ["/search", "⌕", "खोजें"],
  ["/authors", "♙", "लेखक"],
  ["/publications", "▣", "प्रकाशन"],
  ["/works", "✎", "रचनाएँ"],
  ["/categories", "◌", "श्रेणियाँ"],
  ["/calls", "▤", "ओपन कॉल्स"],
  ["/messages", "□", "संदेश"],
  ["/bookmarks", "♡", "बुकमार्क"],
  ["/drafts", "▧", "ड्राफ्ट्स"],
  ["/settings", "⚙", "सेटिंग्स"],
  ["/help", "?", "हेल्प और सपोर्ट"]
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-name">Kavira</div>
        <div className="brand-tagline">शब्दों से जुड़े दिल</div>
      </div>

      <nav className="navigation">
        {items.map(([to, icon, label]) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
          >
            <span className="nav-icon">{icon}</span>
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <NavLink to="/publish" className="write-main">
        ✎ &nbsp; रचना प्रकाशित करें
      </NavLink>
    </aside>
  );
}
