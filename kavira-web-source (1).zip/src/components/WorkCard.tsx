import { useNavigate } from "react-router-dom";
import type { Work } from "../types";

const FALLBACK_COVER =
  "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=700&q=80";

export default function WorkCard({ work }: { work: Work }) {
  const navigate = useNavigate();

  return (
    <article className="work-card" onClick={() => navigate(`/read/${work.id}`)}>
      <img className="work-cover" src={work.coverImage || FALLBACK_COVER} alt={work.title} />
      <div className="work-info">
        <div className="work-title">{work.title}</div>
        <div className="work-author">
          {work.authorName} · {work.type}
        </div>
        <div className="work-meta">
          <span>♡ {work.likesCount}</span>
          <span>□ {work.commentsCount}</span>
          <span>♡ {work.bookmarksCount}</span>
        </div>
      </div>
    </article>
  );
}
