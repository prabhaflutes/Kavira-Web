import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import MobileNav from "./MobileNav";

export default function AppLayout() {
  return (
    <>
      <Sidebar />
      <main className="main">
        <Topbar />
        <div id="page">
          <Outlet />
        </div>
        <footer>
          <span>© 2026 Kavira</span>
          <span>हमारे बारे में · संपर्क · गोपनीयता · नियम</span>
        </footer>
      </main>
      <MobileNav />
    </>
  );
}
