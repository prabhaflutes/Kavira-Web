import { NavLink } from "react-router-dom";

export default function MobileNav() {
  return (
    <nav className="mobile-nav">
      <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
        <span>⌂</span>होम
      </NavLink>
      <NavLink to="/search" className={({ isActive }) => (isActive ? "active" : "")}>
        <span>⌕</span>खोजें
      </NavLink>
      <NavLink to="/publish" className="mobile-write">
        ✎
      </NavLink>
      <NavLink to="/messages" className={({ isActive }) => (isActive ? "active" : "")}>
        <span>□</span>संदेश
      </NavLink>
      <NavLink to="/profile" className={({ isActive }) => (isActive ? "active" : "")}>
        <span>♙</span>प्रोफ़ाइल
      </NavLink>
    </nav>
  );
}
