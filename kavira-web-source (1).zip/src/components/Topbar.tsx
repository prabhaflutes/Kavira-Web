import { useState, type KeyboardEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export default function Topbar() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [query, setQuery] = useState("");

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  }

  return (
    <header className="topbar">
      <div className="search-wrapper">
        <span className="search-icon">⌕</span>
        <input
          className="search"
          placeholder="खोजें रचनाएँ, लेखक, प्रकाशन..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
        />
      </div>

      <div className="top-actions">
        <button className="top-action" onClick={() => navigate("/notifications")}>
          ♧<span className="notification-dot">•</span>
        </button>
        <button className="top-action" onClick={() => navigate("/messages")}>
          □
        </button>
        <img
          className="avatar"
          src={profile?.photoURL || "https://api.dicebear.com/7.x/initials/svg?seed=K"}
          alt="प्रोफ़ाइल"
          onClick={() => navigate("/profile")}
        />
      </div>
    </header>
  );
}
