import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { ToastProvider } from "./components/Toast";
import ProtectedRoute from "./components/ProtectedRoute";
import AppLayout from "./components/AppLayout";

import Login from "./pages/Login";
import AuthComplete from "./pages/AuthComplete";
import Home from "./pages/Home";
import Search from "./pages/Search";
import Authors from "./pages/Authors";
import AuthorProfile from "./pages/AuthorProfile";
import Publications from "./pages/Publications";
import PublicationProfile from "./pages/PublicationProfile";
import Works from "./pages/Works";
import Categories from "./pages/Categories";
import Calls from "./pages/Calls";
import Messages from "./pages/Messages";
import Bookmarks from "./pages/Bookmarks";
import Drafts from "./pages/Drafts";
import Settings from "./pages/Settings";
import Help from "./pages/Help";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import Publish from "./pages/Publish";
import Reading from "./pages/Reading";

export default function App() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.body.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/auth/complete" element={<AuthComplete />} />

            <Route
              element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              }
            >
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Search />} />
              <Route path="/authors" element={<Authors />} />
              <Route path="/author/:id" element={<AuthorProfile />} />
              <Route path="/publications" element={<Publications />} />
              <Route path="/publication/:id" element={<PublicationProfile />} />
              <Route path="/works" element={<Works />} />
              <Route path="/categories" element={<Categories />} />
              <Route path="/calls" element={<Calls />} />
              <Route path="/messages" element={<Messages />} />
              <Route path="/bookmarks" element={<Bookmarks />} />
              <Route path="/drafts" element={<Drafts />} />
              <Route path="/settings" element={<Settings dark={dark} setDark={setDark} />} />
              <Route path="/help" element={<Help />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/publish" element={<Publish />} />
              <Route path="/read/:id" element={<Reading />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  );
}
