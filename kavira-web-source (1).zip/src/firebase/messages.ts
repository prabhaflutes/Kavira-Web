import {
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  type Unsubscribe
} from "firebase/firestore";
import { db } from "./config";
import type { Conversation, Message } from "../types";

const CONVERSATIONS_COL = "conversations";

export function listenToConversations(
  uid: string,
  callback: (conversations: Conversation[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const q = query(
    collection(db, CONVERSATIONS_COL),
    where("participantIds", "array-contains", uid),
    orderBy("lastMessageAt", "desc")
  );
  return onSnapshot(
    q,
    (snap) => {
      callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Conversation)));
    },
    (error) => {
      console.error("Conversations listener error:", error);
      onError?.(error);
    }
  );
}

export function listenToMessages(
  conversationId: string,
  callback: (messages: Message[]) => void
): Unsubscribe {
  const q = query(
    collection(db, CONVERSATIONS_COL, conversationId, "messages"),
    orderBy("createdAt", "asc")
  );
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Message)));
  });
}

export async function getOrCreateConversation(
  currentUid: string,
  currentName: string,
  currentPhoto: string,
  otherUid: string,
  otherName: string,
  otherPhoto: string
): Promise<string> {
  const ids = [currentUid, otherUid].sort();
  const conversationId = ids.join("_");
  const ref = doc(db, CONVERSATIONS_COL, conversationId);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      participantIds: ids,
      participantNames: { [currentUid]: currentName, [otherUid]: otherName },
      participantPhotos: { [currentUid]: currentPhoto, [otherUid]: otherPhoto },
      lastMessage: "",
      lastMessageAt: serverTimestamp()
    });
  }
  return conversationId;
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  text: string
): Promise<void> {
  await addDoc(collection(db, CONVERSATIONS_COL, conversationId, "messages"), {
    conversationId,
    senderId,
    text,
    createdAt: serverTimestamp(),
    read: false
  });
  const { updateDoc } = await import("firebase/firestore");
  await updateDoc(doc(db, CONVERSATIONS_COL, conversationId), {
    lastMessage: text,
    lastMessageAt: serverTimestamp()
  });
}
