import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  serverTimestamp,
  increment,
  type QueryDocumentSnapshot
} from "firebase/firestore";
import { db } from "./config";
import type { Work, WorkType, WorkStatus } from "../types";

const WORKS_COL = "works";
const PAGE_SIZE = 12;

export interface NewWorkInput {
  authorId: string;
  authorName: string;
  authorPhoto: string;
  title: string;
  subtitle?: string;
  content: string;
  coverImage?: string;
  type: WorkType;
  category: string;
  language: string;
  tags: string[];
  status: WorkStatus;
}

export async function createWork(input: NewWorkInput): Promise<string> {
  const ref = await addDoc(collection(db, WORKS_COL), {
    ...input,
    likesCount: 0,
    commentsCount: 0,
    bookmarksCount: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return ref.id;
}

export async function updateWork(
  workId: string,
  changes: Partial<NewWorkInput>
): Promise<void> {
  await updateDoc(doc(db, WORKS_COL, workId), {
    ...changes,
    updatedAt: serverTimestamp()
  });
}

export async function deleteWork(workId: string): Promise<void> {
  await deleteDoc(doc(db, WORKS_COL, workId));
}

export async function getWork(workId: string): Promise<Work | null> {
  const snap = await getDoc(doc(db, WORKS_COL, workId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Work;
}

export async function fetchPublishedWorks(
  cursor?: QueryDocumentSnapshot
): Promise<{ works: Work[]; lastDoc: QueryDocumentSnapshot | null }> {
  const base = query(
    collection(db, WORKS_COL),
    where("status", "==", "published"),
    orderBy("createdAt", "desc"),
    ...(cursor ? [startAfter(cursor)] : []),
    limit(PAGE_SIZE)
  );
  const snap = await getDocs(base);
  const works = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Work));
  const lastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
  return { works, lastDoc };
}

export async function fetchWorksByAuthor(authorId: string): Promise<Work[]> {
  const q = query(
    collection(db, WORKS_COL),
    where("authorId", "==", authorId),
    where("status", "==", "published"),
    orderBy("createdAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Work));
}

export async function fetchDraftsByAuthor(authorId: string): Promise<Work[]> {
  const q = query(
    collection(db, WORKS_COL),
    where("authorId", "==", authorId),
    where("status", "==", "draft"),
    orderBy("updatedAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Work));
}

export async function fetchWorksByCategory(category: string): Promise<Work[]> {
  const q = query(
    collection(db, WORKS_COL),
    where("status", "==", "published"),
    where("category", "==", category),
    orderBy("createdAt", "desc"),
    limit(PAGE_SIZE)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Work));
}

export async function toggleLike(
  workId: string,
  userId: string,
  currentlyLiked: boolean
): Promise<void> {
  const likeRef = doc(db, WORKS_COL, workId, "likes", userId);
  const workRef = doc(db, WORKS_COL, workId);
  if (currentlyLiked) {
    await deleteDoc(likeRef);
    await updateDoc(workRef, { likesCount: increment(-1) });
  } else {
    const { setDoc } = await import("firebase/firestore");
    await setDoc(likeRef, { userId, createdAt: serverTimestamp() });
    await updateDoc(workRef, { likesCount: increment(1) });
  }
}

export async function checkUserLiked(
  workId: string,
  userId: string
): Promise<boolean> {
  const snap = await getDoc(doc(db, WORKS_COL, workId, "likes", userId));
  return snap.exists();
}

export async function toggleBookmark(
  workId: string,
  userId: string,
  currentlyBookmarked: boolean
): Promise<void> {
  const bookmarkRef = doc(db, "users", userId, "bookmarks", workId);
  const workRef = doc(db, WORKS_COL, workId);
  if (currentlyBookmarked) {
    await deleteDoc(bookmarkRef);
    await updateDoc(workRef, { bookmarksCount: increment(-1) });
  } else {
    const { setDoc } = await import("firebase/firestore");
    await setDoc(bookmarkRef, { workId, createdAt: serverTimestamp() });
    await updateDoc(workRef, { bookmarksCount: increment(1) });
  }
}

export async function fetchUserBookmarks(userId: string): Promise<Work[]> {
  const bookmarksSnap = await getDocs(
    collection(db, "users", userId, "bookmarks")
  );
  const workIds = bookmarksSnap.docs.map((d) => d.id);
  const results: Work[] = [];
  for (const id of workIds) {
    const w = await getWork(id);
    if (w) results.push(w);
  }
  return results;
}
