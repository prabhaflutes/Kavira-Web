import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDwVNstg-Wq22AuWhpIvwiNZ_EPeNC0tpY",
  authDomain: "kathansh-7bb0e.firebaseapp.com",
  databaseURL: "https://kathansh-7bb0e-default-rtdb.firebaseio.com",
  projectId: "kathansh-7bb0e",
  storageBucket: "kathansh-7bb0e.firebasestorage.app",
  messagingSenderId: "374510118850",
  appId: "1:374510118850:web:c3dd2ab2843f4f5db1585b",
  measurementId: "G-CCND0JRVVK"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
