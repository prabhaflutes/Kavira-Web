import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  query,
  orderBy,
  limit,
  where,
  serverTimestamp
} from "firebase/firestore";
import { db } from "./config";
import type { Publication, OpenCall } from "../types";

const PUBS_COL = "publications";
const CALLS_COL = "openCalls";

export async function fetchPublications(max = 30): Promise<Publication[]> {
  const q = query(collection(db, PUBS_COL), limit(max));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Publication));
}

export async function getPublication(id: string): Promise<Publication | null> {
  const snap = await getDoc(doc(db, PUBS_COL, id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Publication;
}

export async function createPublication(input: {
  ownerId: string;
  name: string;
  description: string;
  type: string;
  website?: string;
}): Promise<string> {
  const ref = await addDoc(collection(db, PUBS_COL), {
    ...input,
    followersCount: 0,
    verified: false,
    createdAt: serverTimestamp()
  });
  return ref.id;
}

export async function fetchOpenCalls(): Promise<OpenCall[]> {
  const q = query(
    collection(db, CALLS_COL),
    where("status", "==", "open"),
    orderBy("createdAt", "desc"),
    limit(20)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as OpenCall));
}
