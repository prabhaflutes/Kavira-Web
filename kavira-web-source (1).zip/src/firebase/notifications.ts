import {
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  type Unsubscribe
} from "firebase/firestore";
import { db } from "./config";
import type { AppNotification } from "../types";

export function listenToNotifications(
  uid: string,
  callback: (items: AppNotification[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const q = query(
    collection(db, "notifications"),
    where("userId", "==", uid),
    orderBy("createdAt", "desc"),
    limit(30)
  );
  return onSnapshot(
    q,
    (snap) => {
      callback(snap.docs.map((d) => ({ id: d.id, ...d.data() } as AppNotification)));
    },
    (error) => {
      console.error("Notifications listener error:", error);
      onError?.(error);
    }
  );
}
