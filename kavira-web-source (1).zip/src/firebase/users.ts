import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  updateDoc,
  query,
  where,
  limit,
  increment,
  serverTimestamp
} from "firebase/firestore";
import { db } from "./config";
import type { UserProfile } from "../types";

const USERS_COL = "users";

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const snap = await getDoc(doc(db, USERS_COL, uid));
  if (!snap.exists()) return null;
  return snap.data() as UserProfile;
}

export async function updateUserProfile(
  uid: string,
  changes: Partial<UserProfile>
): Promise<void> {
  await updateDoc(doc(db, USERS_COL, uid), changes);
}

export async function fetchWriters(max = 30): Promise<UserProfile[]> {
  const q = query(
    collection(db, USERS_COL),
    where("roles", "array-contains", "writer"),
    limit(max)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as UserProfile);
}

export async function isFollowing(
  currentUid: string,
  targetUid: string
): Promise<boolean> {
  const snap = await getDoc(doc(db, USERS_COL, currentUid, "following", targetUid));
  return snap.exists();
}

export async function toggleFollow(
  currentUid: string,
  targetUid: string,
  currentlyFollowing: boolean
): Promise<void> {
  const followingRef = doc(db, USERS_COL, currentUid, "following", targetUid);
  const followerRef = doc(db, USERS_COL, targetUid, "followers", currentUid);

  if (currentlyFollowing) {
    await deleteDoc(followingRef);
    await deleteDoc(followerRef);
    await updateDoc(doc(db, USERS_COL, currentUid), { followingCount: increment(-1) });
    await updateDoc(doc(db, USERS_COL, targetUid), { followersCount: increment(-1) });
  } else {
    await setDoc(followingRef, { uid: targetUid, createdAt: serverTimestamp() });
    await setDoc(followerRef, { uid: currentUid, createdAt: serverTimestamp() });
    await updateDoc(doc(db, USERS_COL, currentUid), { followingCount: increment(1) });
    await updateDoc(doc(db, USERS_COL, targetUid), { followersCount: increment(1) });
  }
}
